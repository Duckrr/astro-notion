export const siteConfig = {
    site_title : "Astro Notion",
    site_description: "แนวทางการเชื่อมต่อ Astro กับ Notion เพื่อสร้างบล็อกง่ายๆ",
}